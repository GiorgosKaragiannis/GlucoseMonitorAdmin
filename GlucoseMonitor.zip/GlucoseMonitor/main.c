#include <stdio.h>
#include <stdlib.h>

#define N 5
#define LOWERLIMIT 70
#define UPPERLIMIT 120

typedef struct{
    long id;
    int age;
    float glucose;
} patientT;

int calculateGlucose(float glucose);
void populateTable(patientT table[], long ids[], int ages[], float glucose[]);
void getStatistics(patientT table[], float glucose[], int* l, int* u);
void readInput(patientT table[100], int *length);

int main(){
    // Arrays
    long ids[N] = {431252, 22584, 377811002, 55, 13};
    int ages[N] = {25, 52, 64, 33, 29};
    float glucose[N] = {22.19, 132.14, 95.10, 140, 100};
    char* condition[] = {"Hypoglycemy", "Normal", "Hyperglycemy"};

    int i, l, u;
    int length = N;


    for(i = 0; i < N; i++){
        if (ages[i] > 30 && glucose[i] > UPPERLIMIT){
            printf("Patient id: %ld , Age: %d, Glucose: %.2f, Status: %s\n", ids[i], ages[i], glucose[i], condition[calculateGlucose(glucose[i])]);
        }
    }

    patientT tablePatients[100];
    populateTable(tablePatients, ids, ages, glucose);

    printf("_________________\n");
    getStatistics(tablePatients, glucose, &l, &u);
    printf("Number of patients with Hypoglycemy: %d\nNumber of patients with Hyperglycemy: %d\n", l, u);
    printf("_________________\n");


    readInput(tablePatients, &length);


    for (i = N; i < length; i++)
    {
        printf("Patient id: %15ld, Age: %3d, Glucose: %7.2f, Status: %10s\n", tablePatients[i].id, tablePatients[i].age, tablePatients[i].glucose, condition[calculateGlucose(tablePatients[i].glucose)]);
    }

    return 0;
}

int calculateGlucose(float glucose){
    if(glucose < LOWERLIMIT)
        return 0;
    else if(glucose > UPPERLIMIT)
        return 2;
    else
        return 1;
}

void populateTable(patientT tablePatients[], long ids[], int ages[], float glucose[]){
    int i;
    for(i = 0; i < N; i++){
        tablePatients[i].age = ages[i];
        tablePatients[i].glucose = glucose[i];
        tablePatients[i].id = ids[i];
    }
}

void getStatistics(patientT table[], float glucose[], int* l, int* u){
    int i;
    (*l) = 0;
    (*u) = 0;
    for(i = 0; i < N; i++){
        if(calculateGlucose(glucose[i]) == 0)
            (*l)++;
        if(calculateGlucose(glucose[i]) == 2)
            (*u)++;
    }
}

void readInput(patientT table[100], int *length){
    FILE *infile;
    infile = fopen("patients.csv", "r");
    if (infile == NULL) {
        printf("\nERROR: File 'patients.csv' not found!\n");
        printf("Make sure the file is in the same folder as the project.\n");
        return;
    }

    int nscan;
    long id;
    int age;
    float glucose;
    char term;

    while (1)
    {
        nscan = fscanf(infile, "%ld, %d, %f%c", &id, &age, &glucose, &term);
        if (nscan == EOF)
        {
            break;
        }

        table[(*length)].glucose = glucose;
        table[(*length)].age = age;
        table[(*length)].id = id;
        (*length)++;
    }

    fclose(infile);
}
